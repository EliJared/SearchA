﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchEngine
{
    public static class Global
    {
        public static string Usename = "User:";
        public static string Pass = "Pass";
        public static string Pet = "Fido";
        public static int Age = 1;
        public static string spcies = "Doggo";
    }
}
